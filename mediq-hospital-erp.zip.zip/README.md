# MEDIQ Hospital ERP
**Smart Hospital Management and Online Appointment Booking System**
Flask + SQLite + Bootstrap 5 + Chart.js

> ⚠️ **Educational demonstration only.** This prototype uses synthetic (fake) data. Before any real hospital use it must go through a proper security, privacy and regulatory review (for example HIPAA, GDPR or your country's health-data law).
>
> **Verification is simulated.** The app checks patient details against a small *demonstration* registry stored in `config.py`. It does **not** verify real identity documents, insurance eligibility or external hospital records. **Email and SMS are not sent**; notifications are in-app only.
>
> **Not deployed.** This project has been built and tested locally only. Follow the deployment guide below to put it online with your own account.

---

## 1. How it works (simple explanation)

```
 Browser (HTML + Bootstrap + a little JavaScript)
        │  sends requests (clicks, forms)
        ▼
 Flask application (app.py)  ── checks: logged in? right role? valid data? CSRF token?
        │  reads / writes with parameterized SQL
        ▼
 SQLite database (mediq.db)  ── 9 tables, keys, constraints, unique index against double-booking
```

* **Templates** (`templates/*.html`) build the pages. Jinja fills in data from the database.
* **`app.py`** holds all routes (URLs), security checks, validation and booking logic. It is organised in numbered sections.
* **`schema.sql`** creates the 9 tables. The app runs it automatically at start-up.
* **`seed_data.py`** fills the database with fake demonstration data.
* Bootstrap and Chart.js are **included in `static/vendor/`**, so the site works without internet access and without third-party scripts.

## 2. Project structure

```
mediq-hospital-erp/
├── app.py                 # routes, security, validation, booking logic
├── config.py              # settings read from environment variables + demo registry
├── schema.sql             # database tables, keys, constraints, indexes
├── seed_data.py           # synthetic demo data
├── create_admin.py        # create the first real administrator (no demo data)
├── backup_db.py           # safe database backup
├── requirements.txt
├── templates/             # 24 HTML files (layout, macros, one per page)
├── static/css/style.css   # blue/teal theme
├── static/js/main.js      # table filters, loading spinners, charts
├── static/vendor/         # Bootstrap 5 and Chart.js (local copies)
├── tests/                 # 58 automated tests
└── docs/DATABASE.md       # ER diagram, keys, relationships, CRUD, viva questions
```

## 3. Run it on your computer

You need **Python 3.9 or newer** ([python.org](https://www.python.org/downloads/)). Open a terminal (Command Prompt / PowerShell on Windows) **inside the project folder**.

```bash
# 1. Create and activate a virtual environment (keeps packages tidy)
python -m venv .venv
.venv\Scripts\activate            # Windows
source .venv/bin/activate         # macOS / Linux

# 2. Install the packages
pip install -r requirements.txt

# 3. Create the database and fill it with fake demo data
python seed_data.py

# 4. Start the website
python app.py
```

Open **http://127.0.0.1:5000** in your browser. To start again from scratch: `python seed_data.py --reset`.

### Demonstration logins (fake accounts)

All demo accounts use the password **`Demo@12345`**.

| Role | Email | Notes |
|------|-------|-------|
| Administrator | `admin@example.com` | full admin area |
| Doctor | `dr.verma@example.com` | Cardiology (also `dr.mehta@`, `dr.iyer@`, `dr.singh@`, `dr.kapoor@example.com`) |
| Patient: **Verified** | `patient1@example.com` | can book; has shared and private records |
| Patient: **Requires Review** | `patient2@example.com` | has insurance, so needs human review; cannot book |
| Patient: **Pending** | `patient3@example.com` | no identifier given; cannot book |
| Patient: **Rejected** | `patient4@example.com` | cannot book |
| Patient: **Verified** | `patient5@example.com` | second verified patient for double-booking tests |

Demo registry identifiers you can use when registering a new patient (the name and date of birth must match):

| Identifier | Name | Date of birth |
|------------|------|---------------|
| `MQ-100005` | Demo Patient Six | 1988-08-08 |
| `MQ-100006` | Demo Patient Seven | 1991-01-01 |

## 4. What each role can do

**Patient**: register (with automatic validation), log in/out, see verification status, search doctors by name / department / specialty / date / availability, view free slots, book, view upcoming and previous appointments, cancel or reschedule (at least 2 hours before the start), edit permitted profile fields, read records their doctor has shared.

**Doctor**: see daily and weekly schedule and appointment history, add availability windows, mark windows available/unavailable, set qualification and consultation length, confirm/complete/cancel appointments, write consultation notes (and choose whether the patient may see them). Doctors only see patients of their own appointments, and only the fields needed for care (no address, insurance or identifier).

**Administrator**: dashboard with live statistics and Chart.js charts, manage doctors (add/edit/deactivate), departments, patients, verification review, appointments, users (deactivate, add administrators), reports (department counts, doctor utilization, audit log). Administrators do not see consultation notes.

### Business rules

| Rule | Where |
|------|-------|
| Only **Verified** patients may book. Rejected patients are always blocked. | `booking_allowed()`; admin policy `ALLOW_UNVERIFIED_BOOKING=1` relaxes it for Pending / Requires Review |
| Insurance is **never auto-approved**; it always becomes "Requires Review". Changing insurance later also triggers review. | `run_demo_verification()`, `patient_profile()` |
| A slot can be booked once; cancelled slots become free again. | `schema.sql` unique index + `validate_slot()` + `transaction()` |
| Patients cancel/reschedule at least `CANCELLATION_NOTICE_HOURS` (default 2) before the start. Admins and doctors can cancel any open appointment. | `can_cancel()` |
| "Completed" can be set only after the appointment has started. | `appointment_status()` |

## 5. Test it

### Automated tests (fake data only)

```bash
python -m unittest discover -s tests -v
```

58 tests cover: registration, duplicate email / identifier / record prevention, validation messages, verification outcomes, login (valid and invalid), inactive users, CSRF, role-based access (page **and** action endpoints), profile access, verification workflow, doctor availability, successful booking, **double-booking prevention** (sequential, database-level, and two simultaneous requests), cancellation rules, rescheduling, doctor status updates, medical-record privacy, dashboard statistics, and that every page renders.

### Manual test checklist (about 10 minutes)

1. **Register**: open `/register`, submit an empty form (see messages), then register with a bad email, then correctly. You are logged in and see a status.
2. **Duplicate email**: log out and register again with the same email. It is refused.
3. **Login**: try a wrong password (generic error), then `patient1@example.com`.
4. **Role protection**: while logged in as a patient, open `/admin/dashboard`. You get "Access denied".
5. **Verification**: log in as `patient3@example.com` → try to book → blocked. Log in as admin → *Verification review* → set Verified. Patient receives a notification and can now book.
6. **Book**: as `patient1`, *Find a doctor* → pick a date → click a time → confirm. See it under *My appointments*.
7. **Double booking**: open two browsers (or one normal + one private window). Log in as `patient1` and `patient5`, open the same doctor and slot, click Book in both. Only the first succeeds.
8. **Cancel / reschedule**: use the buttons on *My appointments*.
9. **Doctor**: log in as `dr.verma@example.com`, add an availability window, mark it unavailable, open *Notes* for an appointment, tick "Share with patient". Log in as the patient and see the record in *My profile*.
10. **Admin dashboard**: numbers change after each step above (they come from real SQL queries). Check *Reports* and the audit log.

## 6. Deploy online (beginner-friendly: PythonAnywhere)

PythonAnywhere runs Flask apps, keeps your files (so SQLite data **persists**), and has a free tier that is enough for a college demo. Their limits and screens change from time to time, so check their help pages if something looks different.

1. **Create an account** at [pythonanywhere.com](https://www.pythonanywhere.com) (a free "Beginner" account is fine). Your site will be `https://YOURUSERNAME.pythonanywhere.com`.
2. **Upload the project**: *Files* tab → upload `mediq-hospital-erp.zip` to your home folder.
3. **Open a Bash console** (*Consoles* tab → *Bash*) and run:
   ```bash
   unzip mediq-hospital-erp.zip
   cd mediq-hospital-erp
   mkvirtualenv mediq --python=python3.10     # use a Python 3.9+ version that PythonAnywhere offers
   pip install -r requirements.txt
   python -c "import secrets; print(secrets.token_hex(32))"   # copy this output: it is your SECRET_KEY
   python seed_data.py                         # demo data (see step 7 for a clean production start)
   ```
4. **Create the web app**: *Web* tab → *Add a new web app* → *Manual configuration* → choose the same Python version.
5. On the *Web* tab set:
   * **Source code**: `/home/YOURUSERNAME/mediq-hospital-erp`
   * **Virtualenv**: `/home/YOURUSERNAME/.virtualenvs/mediq`
6. **Edit the WSGI file** (link on the *Web* tab). Replace everything with:
   ```python
   import os, sys
   path = "/home/YOURUSERNAME/mediq-hospital-erp"
   if path not in sys.path:
       sys.path.insert(0, path)

   os.environ["SECRET_KEY"] = "PASTE-THE-LONG-RANDOM-VALUE-HERE"
   os.environ["MEDIQ_ENV"] = "production"            # refuses to start with a weak key
   os.environ["SESSION_COOKIE_SECURE"] = "1"         # cookies only over HTTPS
   os.environ["SHOW_DEMO_CREDENTIALS"] = "1"         # set to "0" for real use
   os.environ["DATABASE_PATH"] = "/home/YOURUSERNAME/mediq-hospital-erp/mediq.db"

   from app import app as application
   ```
7. Click the green **Reload** button, then open your site URL.

**Starting clean (no demo data) for real use:** instead of `python seed_data.py`, run `python create_admin.py` and answer the prompts. Then set `SHOW_DEMO_CREDENTIALS` to `"0"`.

**Other hosts:** any host that runs Python/Flask works, using `gunicorn app:app` as the start command (for example Render or Railway). Many free plans have a **temporary disk**, so SQLite data would be lost on redeploy or restart. On those hosts use a persistent disk (usually a paid feature) or migrate to a hosted PostgreSQL database (see `docs/DATABASE.md`, section 9).

### Production configuration (environment variables)

| Variable | Purpose | Default |
|----------|---------|---------|
| `SECRET_KEY` | signs session cookies. **Required** in production; long and random | dev placeholder |
| `MEDIQ_ENV` | set `production` to refuse weak keys | `development` |
| `DATABASE_PATH` | location of the SQLite file (put it on persistent storage) | `./mediq.db` |
| `SESSION_COOKIE_SECURE` | `1` when the site uses HTTPS | `0` |
| `SHOW_DEMO_CREDENTIALS` | show the demo accounts on the login page | `1` |
| `ALLOW_UNVERIFIED_BOOKING` | administrator policy: allow Pending / Requires Review patients to book | `0` |
| `CANCELLATION_NOTICE_HOURS` | notice needed for patient cancellation | `2` |
| `BOOKING_WINDOW_DAYS` | how many days ahead patients can see slots | `14` |

Never put secrets in the code or in GitHub. The `.gitignore` already excludes `*.db` and `.env`.

### Persistent storage and backups

* On PythonAnywhere your project folder (and `mediq.db`) is kept between restarts.
* **Back up regularly**: `python backup_db.py` creates a consistent copy in `backups/`. Download it from the *Files* tab. Backups contain patient data, so store them securely.
* Restore: stop the app, replace `mediq.db` with the backup file, reload.
* For many users or high availability, move to PostgreSQL (hosted by Supabase, Neon, Render, etc.).

## 7. Security features

* Passwords hashed with scrypt (Werkzeug); never stored in plain text.
* Session cookies are HttpOnly, SameSite=Lax, optionally Secure; sessions expire after 60 minutes; the session is renewed at login.
* CSRF token on every state-changing form; logout is a POST.
* Role-based access on **every** page and action endpoint; users are re-checked on each request, so deactivation takes effect immediately.
* All SQL is parameterized; all input is validated on the server; templates auto-escape output.
* Same error message for every failed login; password check runs even for unknown emails.
* Open-redirect protection, security headers and a strict Content-Security-Policy (no third-party scripts).
* Audit log for registration, login/logout, bookings, cancellations, verification changes, record changes, and admin actions.
* Data minimisation: doctors see only what a consultation needs; administrators do not see consultation notes; patients see only records explicitly shared.

### Known limitations (good "future work" for your report)

* No login-attempt rate limiting or two-factor authentication.
* No password-reset email, no real email/SMS (hook: `deliver_external()` in `app.py`).
* Times use the server's clock/time zone (PythonAnywhere uses UTC). Set the hosting time zone or add time-zone support before real use.
* Cancelling or marking a doctor window unavailable does not auto-cancel appointments already booked in it.
* SQLite suits a demo or small clinic; use PostgreSQL for many simultaneous users.
* Real verification would need authorised integrations with identity and insurance providers.

## 8. Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError: flask` | activate the virtual environment, then `pip install -r requirements.txt` |
| "Your form expired or was invalid" | refresh the page and try again (the session or CSRF token expired) |
| Website shows an old database | `python seed_data.py --reset` (this deletes all data) |
| Cannot log in after deploying | run `python seed_data.py` or `python create_admin.py` against the **same** `DATABASE_PATH` that the WSGI file uses |
| Changes not visible on PythonAnywhere | click **Reload** on the *Web* tab |
| "Set a strong SECRET_KEY" error | set `SECRET_KEY` in the WSGI file (step 6) |
