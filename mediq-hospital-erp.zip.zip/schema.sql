-- =====================================================================
-- MEDIQ Hospital ERP: database schema (SQLite)
-- Written with standard SQL types so it can be migrated to PostgreSQL later
-- (see docs/DATABASE.md). Foreign keys are switched on for every connection
-- by the application (PRAGMA foreign_keys = ON).
-- =====================================================================

-- 1. USERS: everyone who can log in (patients, doctors, administrators)
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,                       -- never plain text
    role          TEXT NOT NULL CHECK (role IN ('patient', 'doctor', 'admin')),
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 2. PATIENTS: one-to-one with users (UNIQUE user_id)
-- Extra columns beyond the brief: medical_history, registration_symptoms and
-- verification_note (needed to store what the registration form collects).
CREATE TABLE IF NOT EXISTS patients (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                     INTEGER NOT NULL UNIQUE REFERENCES users (id),
    date_of_birth               TEXT NOT NULL,
    gender                      TEXT CHECK (gender IN ('Female', 'Male', 'Other', 'Prefer not to say')),
    phone                       TEXT NOT NULL,
    address                     TEXT,
    patient_identifier          TEXT UNIQUE COLLATE NOCASE,   -- NULL allowed, duplicates not
    insurance_provider          TEXT,
    insurance_policy_reference  TEXT,
    medical_history             TEXT,
    registration_symptoms       TEXT,
    verification_status         TEXT NOT NULL DEFAULT 'Pending'
        CHECK (verification_status IN ('Pending', 'Verified', 'Requires Review', 'Rejected')),
    verification_note           TEXT,
    created_at                  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 3. DEPARTMENTS (is_active added so a department can be deactivated)
CREATE TABLE IF NOT EXISTS departments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    department_name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    description     TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- 4. DOCTORS: one-to-one with users; many doctors belong to one department
CREATE TABLE IF NOT EXISTS doctors (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id               INTEGER NOT NULL UNIQUE REFERENCES users (id),
    department_id         INTEGER NOT NULL REFERENCES departments (id),
    specialty             TEXT NOT NULL,
    qualification         TEXT,
    consultation_duration INTEGER NOT NULL DEFAULT 30
        CHECK (consultation_duration BETWEEN 10 AND 120),   -- minutes
    is_active             INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- 5. DOCTOR_AVAILABILITY: time windows in which a doctor sees patients
CREATE TABLE IF NOT EXISTS doctor_availability (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id      INTEGER NOT NULL REFERENCES doctors (id),
    available_date TEXT NOT NULL,            -- YYYY-MM-DD
    start_time     TEXT NOT NULL,            -- HH:MM (24 hour)
    end_time       TEXT NOT NULL,
    is_available   INTEGER NOT NULL DEFAULT 1 CHECK (is_available IN (0, 1)),
    CHECK (start_time < end_time),
    UNIQUE (doctor_id, available_date, start_time)
);

-- 6. APPOINTMENTS
CREATE TABLE IF NOT EXISTS appointments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id       INTEGER NOT NULL REFERENCES patients (id),
    doctor_id        INTEGER NOT NULL REFERENCES doctors (id),
    appointment_date TEXT NOT NULL,
    start_time       TEXT NOT NULL,
    end_time         TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'Booked'
        CHECK (status IN ('Booked', 'Confirmed', 'Completed', 'Cancelled')),
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (start_time < end_time)
);

-- DOUBLE-BOOKING PROTECTION (enforced by the database itself):
-- a doctor can have only ONE non-cancelled appointment for the same date and
-- start time. Cancelled appointments are ignored, so the slot becomes free again.
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_doctor_slot
    ON appointments (doctor_id, appointment_date, start_time)
    WHERE status IN ('Booked', 'Confirmed', 'Completed');

-- 7. MEDICAL_RECORDS (visible_to_patient added: the doctor decides what the
-- patient may see)
CREATE TABLE IF NOT EXISTS medical_records (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id         INTEGER NOT NULL REFERENCES patients (id),
    doctor_id          INTEGER REFERENCES doctors (id),
    appointment_id     INTEGER REFERENCES appointments (id),
    symptoms           TEXT,
    consultation_notes TEXT,
    diagnosis          TEXT,
    visible_to_patient INTEGER NOT NULL DEFAULT 0 CHECK (visible_to_patient IN (0, 1)),
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
-- at most one consultation record per appointment
CREATE UNIQUE INDEX IF NOT EXISTS uq_record_per_appointment
    ON medical_records (appointment_id) WHERE appointment_id IS NOT NULL;

-- 8. NOTIFICATIONS (in-app)
CREATE TABLE IF NOT EXISTS notifications (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           INTEGER NOT NULL REFERENCES users (id),
    appointment_id    INTEGER REFERENCES appointments (id),
    message           TEXT NOT NULL,
    notification_type TEXT NOT NULL,
    is_read           INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
    created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 9. AUDIT_LOGS: who did what, and when
CREATE TABLE IF NOT EXISTS audit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users (id),
    action      TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id   INTEGER,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Indexes that speed up the most common searches
CREATE INDEX IF NOT EXISTS idx_patients_status       ON patients (verification_status);
CREATE INDEX IF NOT EXISTS idx_doctors_department    ON doctors (department_id);
CREATE INDEX IF NOT EXISTS idx_avail_doctor_date     ON doctor_availability (doctor_id, available_date);
CREATE INDEX IF NOT EXISTS idx_appt_patient          ON appointments (patient_id);
CREATE INDEX IF NOT EXISTS idx_appt_doctor_date      ON appointments (doctor_id, appointment_date);
CREATE INDEX IF NOT EXISTS idx_records_patient       ON medical_records (patient_id);
CREATE INDEX IF NOT EXISTS idx_notif_user_read       ON notifications (user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_audit_created         ON audit_logs (created_at);
