# MEDIQ: Database Design (DBMS project notes)

Database: **SQLite** (file `mediq.db`). The schema is in [`../schema.sql`](../schema.sql).
Foreign keys are switched on for every connection with `PRAGMA foreign_keys = ON`.

## 1. ER diagram

If your viewer does not render the diagram below (GitHub does), use the text version in section 2.

```mermaid
erDiagram
    users ||--o| patients : "has one profile"
    users ||--o| doctors : "has one profile"
    users ||--o{ notifications : receives
    users ||--o{ audit_logs : performs
    departments ||--o{ doctors : employs
    doctors ||--o{ doctor_availability : sets
    doctors ||--o{ appointments : "is booked for"
    patients ||--o{ appointments : books
    patients ||--o{ medical_records : has
    doctors ||--o{ medical_records : writes
    appointments |o--o| medical_records : "may have"
    appointments |o--o{ notifications : "may trigger"

    users { int id PK
            text full_name
            text email UK
            text password_hash
            text role
            int is_active
            text created_at }
    patients { int id PK
               int user_id FK,UK
               text date_of_birth
               text gender
               text phone
               text address
               text patient_identifier UK
               text insurance_provider
               text insurance_policy_reference
               text verification_status
               text created_at
               text updated_at }
    departments { int id PK
                  text department_name UK
                  text description
                  int is_active }
    doctors { int id PK
              int user_id FK,UK
              int department_id FK
              text specialty
              text qualification
              int consultation_duration
              int is_active }
    doctor_availability { int id PK
                          int doctor_id FK
                          text available_date
                          text start_time
                          text end_time
                          int is_available }
    appointments { int id PK
                   int patient_id FK
                   int doctor_id FK
                   text appointment_date
                   text start_time
                   text end_time
                   text status
                   text created_at }
    medical_records { int id PK
                      int patient_id FK
                      int doctor_id FK
                      int appointment_id FK
                      text symptoms
                      text consultation_notes
                      text diagnosis
                      int visible_to_patient
                      text created_at
                      text updated_at }
    notifications { int id PK
                    int user_id FK
                    int appointment_id FK
                    text message
                    text notification_type
                    int is_read
                    text created_at }
    audit_logs { int id PK
                 int user_id FK
                 text action
                 text entity_type
                 int entity_id
                 text created_at }
```

## 2. ER diagram (text version)

```
                          +-----------+
        +---------------> |  users    | <----------------+
        | 1               +-----------+               1  |
        |                  | 1      | 1                  |
        |  (one-to-one)    |        |    (one-to-one)    |
        | 0..1             | 1..*   | 1..*          0..1 |
   +----------+     +---------------+  +-----------+  +---------+
   | patients |     | notifications |  | audit_logs|  | doctors |
   +----------+     +---------------+  +-----------+  +---------+
     | 1   | 1                                          | 1  | 1   | *
     |     |                                            |    |     +----> departments (many doctors : 1 department)
     | *   | *               * |                        | *  | *
 +--------------+   +---------------------+      +---------------------+
 | appointments |<--| (patient_id)        |      | doctor_availability |
 +--------------+   +---------------------+      +---------------------+
     | 0..1      (a doctor also has MANY appointments via doctor_id)
     | 
     | 0..1
 +-----------------+   (medical_records also reference patient_id and doctor_id)
 | medical_records |
 +-----------------+
```

## 3. Keys

| Kind | Where |
|------|-------|
| **Primary keys** | `id` (auto-increment integer) in every table |
| **Foreign keys** | `patients.user_id → users.id`, `doctors.user_id → users.id`, `doctors.department_id → departments.id`, `doctor_availability.doctor_id → doctors.id`, `appointments.patient_id → patients.id`, `appointments.doctor_id → doctors.id`, `medical_records.patient_id / doctor_id / appointment_id`, `notifications.user_id / appointment_id`, `audit_logs.user_id` |
| **Unique constraints** | `users.email` (case-insensitive), `patients.user_id`, `doctors.user_id` (these two make the relationship one-to-one), `patients.patient_identifier`, `departments.department_name`, `(doctor_id, available_date, start_time)` in availability |
| **Partial unique indexes** | `uq_active_doctor_slot` (no double booking) and `uq_record_per_appointment` (one record per appointment) |
| **CHECK constraints** | role, verification status, appointment status, gender, 0/1 flags, `start_time < end_time`, consultation duration 10 to 120 |

## 4. Relationships

| Relationship | Type | How it is implemented |
|--------------|------|-----------------------|
| user ↔ patient profile | **one-to-one** | `patients.user_id` is a FK **and UNIQUE** |
| user ↔ doctor profile | **one-to-one** | `doctors.user_id` is a FK **and UNIQUE** |
| department → doctors | **one-to-many** | `doctors.department_id` FK |
| patient → appointments | **one-to-many** | `appointments.patient_id` FK |
| doctor → appointments | **one-to-many** | `appointments.doctor_id` FK |
| doctor → availability | **one-to-many** | `doctor_availability.doctor_id` FK |
| patient → medical records | **one-to-many** | `medical_records.patient_id` FK |
| user → notifications | **one-to-many** | `notifications.user_id` FK |
| appointment ↔ medical record | **one-to-zero-or-one** | `medical_records.appointment_id` FK (nullable) + unique index |

Patients and doctors are in a **many-to-many** relationship (a patient sees many doctors, a doctor sees many patients). It is resolved by the `appointments` table, which is the "junction" (associative) table.

## 5. Columns added to the brief's tables

Each addition has a reason and is marked in `schema.sql`:

| Table | Column | Reason |
|-------|--------|--------|
| patients | `medical_history`, `registration_symptoms` | the registration form collects them |
| patients | `verification_note` | explains *why* a status was chosen |
| departments | `is_active` | departments can be deactivated |
| medical_records | `visible_to_patient` | the doctor chooses which records the patient may read |

## 6. Double-booking prevention (transaction-safe)

Three layers protect a slot:

1. **Backend check** (`validate_slot`): the slot must lie inside an available window, be in the future, and not overlap an existing appointment.
2. **Transaction**: booking runs inside `BEGIN IMMEDIATE ... COMMIT`. SQLite takes the write lock first, so two simultaneous requests are processed one after the other. The second one sees the first booking and is refused.
3. **Database constraint** (last line of defence):

```sql
CREATE UNIQUE INDEX uq_active_doctor_slot
    ON appointments (doctor_id, appointment_date, start_time)
    WHERE status IN ('Booked', 'Confirmed', 'Completed');
```

A cancelled appointment is not in the index, so its slot can be booked again.
Tests `test_database_itself_blocks_double_booking` and `test_simultaneous_bookings_only_one_succeeds` prove this.

## 7. CRUD operations and the SQL behind them

| Entity | Create | Read | Update | Delete / deactivate |
|--------|--------|------|--------|---------------------|
| Patient | `INSERT INTO users` + `INSERT INTO patients` (one transaction) on `/register` | own profile `SELECT ... WHERE user_id = ?` | `UPDATE patients SET phone=?, ...` (permitted fields only) | account deactivated (`users.is_active = 0`); rows are kept for audit |
| Doctor | admin: `INSERT INTO users` + `INSERT INTO doctors` | public directory (JOIN users, departments) | admin edit, or doctor edits own qualification and duration | `is_active = 0` (soft delete) |
| Department | admin `INSERT INTO departments` | list with doctor counts (`LEFT JOIN ... GROUP BY`) | `UPDATE departments SET ...` | `is_active = 0` |
| Availability | doctor `INSERT INTO doctor_availability` | free slots computed from windows minus appointments | toggle `is_available` | mark unavailable |
| Appointment | `INSERT INTO appointments` (inside a transaction) | role-filtered `SELECT` with JOINs | reschedule = `UPDATE` date/time; status changes | `status = 'Cancelled'` (history is kept) |
| Medical record | doctor `INSERT INTO medical_records` | doctor: own appointments; patient: `visible_to_patient = 1` only | `UPDATE medical_records ...` | not deleted |
| Notification | `INSERT` on every important event | `SELECT ... WHERE user_id = ?` | `UPDATE ... SET is_read = 1` | n/a |
| Audit log | `INSERT` on every important action | admin reports page | never updated | never deleted |

Records are *deactivated or cancelled* rather than deleted, which keeps history and keeps foreign keys valid.

## 8. Useful queries to show in a viva

```sql
-- Appointments per department (LEFT JOIN keeps departments with zero)
SELECT dep.department_name, COUNT(a.id)
FROM departments dep
LEFT JOIN doctors d ON d.department_id = dep.id
LEFT JOIN appointments a ON a.doctor_id = d.id AND a.status != 'Cancelled'
GROUP BY dep.id;

-- Today's schedule for one doctor
SELECT a.start_time, u.full_name
FROM appointments a JOIN patients p ON p.id = a.patient_id JOIN users u ON u.id = p.user_id
WHERE a.doctor_id = 1 AND a.appointment_date = date('now') AND a.status != 'Cancelled'
ORDER BY a.start_time;

-- Patients waiting for a verification decision
SELECT u.full_name, p.verification_status FROM patients p JOIN users u ON u.id = p.user_id
WHERE p.verification_status IN ('Pending', 'Requires Review');
```

## 9. Moving to PostgreSQL later

The schema uses plain SQL on purpose. When you migrate:

| SQLite (now) | PostgreSQL |
|--------------|------------|
| `INTEGER PRIMARY KEY AUTOINCREMENT` | `SERIAL PRIMARY KEY` (or `GENERATED ALWAYS AS IDENTITY`) |
| `TEXT` dates and times (`YYYY-MM-DD`, `HH:MM`) | `DATE` and `TIME` columns |
| `INTEGER` 0/1 flags | `BOOLEAN` |
| `datetime('now')` default | `now()` / `CURRENT_TIMESTAMP` |
| `COLLATE NOCASE` | `CITEXT` type or a `lower(email)` unique index |
| `?` placeholders | `%s` placeholders (psycopg2) or SQLAlchemy |
| `BEGIN IMMEDIATE` | normal transaction; use `SELECT ... FOR UPDATE` or rely on the unique index |
| `PRAGMA foreign_keys = ON` | not needed (always enforced) |

Partial unique indexes (`CREATE UNIQUE INDEX ... WHERE ...`) work the same way in PostgreSQL. All SQL is inside `app.py`, so the work is a search-and-replace of placeholders plus a new connection function.

## 10. Sample viva questions

1. **What is a foreign key?** A column that refers to the primary key of another table, so the database rejects rows that point to something that does not exist.
2. **How is a one-to-one relationship made?** A foreign key that is also UNIQUE (`patients.user_id`).
3. **Why is `appointments` called a junction table?** It resolves the many-to-many relationship between patients and doctors.
4. **How do you stop two patients booking the same slot?** Backend checks, a write transaction (`BEGIN IMMEDIATE`) and a partial unique index.
5. **What is a transaction?** A group of statements that all succeed (COMMIT) or all fail (ROLLBACK), for example creating a user and the patient profile together.
6. **Why not store passwords as text?** If the database leaks, plain passwords are exposed. We store salted hashes (scrypt).
7. **What is SQL injection?** Malicious text changing a query. We prevent it with `?` placeholders (parameterized queries).
8. **Why use soft delete (`is_active`)?** It keeps history and referential integrity for appointments and audit logs.
