"""
Create the database and fill it with SYNTHETIC demonstration data.

    python seed_data.py            # create tables + demo data (skips if users exist)
    python seed_data.py --reset    # delete the database file and start fresh

Every name, email and phone number below is fake. Do not use real patient data.
All demo accounts share the password:  Demo@12345
"""
import argparse
import os
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

from app import connect, init_db
from config import Config

DEMO_PASSWORD = "Demo@12345"

DEPARTMENTS = [
    ("Cardiology", "Heart and blood-vessel care"),
    ("Neurology", "Brain, spine and nervous system"),
    ("Pediatrics", "Health care for children"),
    ("Orthopedics", "Bones, joints and muscles"),
    ("General Medicine", "First point of contact for common illnesses"),
]

# (name, email, department, specialty, qualification, minutes per consultation)
DOCTORS = [
    ("Dr. Asha Verma", "dr.verma@example.com", "Cardiology", "Interventional Cardiology", "MD, DM (Cardiology)", 30),
    ("Dr. Rohan Mehta", "dr.mehta@example.com", "Neurology", "Neurophysiology", "MD, DM (Neurology)", 30),
    ("Dr. Meera Iyer", "dr.iyer@example.com", "Pediatrics", "Child Development", "MD (Pediatrics)", 20),
    ("Dr. Karan Singh", "dr.singh@example.com", "Orthopedics", "Sports Injuries", "MS (Orthopedics)", 30),
    ("Dr. Neha Kapoor", "dr.kapoor@example.com", "General Medicine", "Family Medicine", "MBBS, MD", 15),
]

# (name, email, dob, gender, phone, identifier, insurance provider, policy, status, note, history, symptoms)
PATIENTS = [
    ("Demo Patient One", "patient1@example.com", "1990-05-14", "Female", "9000000001", "MQ-100001", None, None,
     "Verified", "Name, date of birth and identifier matched the demonstration registry (simulated check).",
     "Seasonal allergies (fake data)", "Occasional chest tightness"),
    ("Demo Patient Two", "patient2@example.com", "1985-11-02", "Male", "9000000002", "MQ-100002", "DemoCare Insurance", "DC-2024-0001",
     "Requires Review", "Identity matched the demonstration registry. Insurance cannot be verified automatically and needs human review.",
     "None", "Back pain"),
    ("Demo Patient Three", "patient3@example.com", "2000-01-20", "Other", "9000000003", None, None, None,
     "Pending", "No patient identifier given; waiting for staff review.", "None", "Headache"),
    ("Demo Patient Four", "patient4@example.com", "1975-07-30", None, "9000000004", "ZZ-999999", None, None,
     "Rejected", "Demonstration: identifier could not be matched and staff rejected the registration.", "None", "Cough"),
    ("Demo Patient Five", "patient5@example.com", "1995-03-09", "Female", "9000000005", "MQ-100004", None, None,
     "Verified", "Name, date of birth and identifier matched the demonstration registry (simulated check).", "None", "Knee pain"),
]


def seed(path=None, reset=False):
    """Create schema + demo data. Returns True if data was added."""
    path = path or Config.DATABASE
    if reset and os.path.exists(path):
        os.remove(path)
    init_db(path)
    db = connect(path)
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
        db.close()
        return False

    def add_user(name, email, role):
        return db.execute("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                          (name, email, generate_password_hash(DEMO_PASSWORD), role)).lastrowid

    db.execute("BEGIN IMMEDIATE")
    add_user("Admin User", "admin@example.com", "admin")

    dept_ids = {}
    for name, desc in DEPARTMENTS:
        dept_ids[name] = db.execute("INSERT INTO departments (department_name, description) VALUES (?, ?)", (name, desc)).lastrowid

    doctor_ids = []
    for name, email, dept, specialty, qualification, minutes in DOCTORS:
        uid = add_user(name, email, "doctor")
        doctor_ids.append(db.execute(
            "INSERT INTO doctors (user_id, department_id, specialty, qualification, consultation_duration) VALUES (?, ?, ?, ?, ?)",
            (uid, dept_ids[dept], specialty, qualification, minutes)).lastrowid)

    patient_ids, patient_user_ids = [], []
    for (name, email, dob, gender, phone, ident, prov, pol, status, note, history, symptoms) in PATIENTS:
        uid = add_user(name, email, "patient")
        patient_user_ids.append(uid)
        patient_ids.append(db.execute(
            "INSERT INTO patients (user_id, date_of_birth, gender, phone, address, patient_identifier, insurance_provider, "
            "insurance_policy_reference, medical_history, registration_symptoms, verification_status, verification_note) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (uid, dob, gender, phone, "12 Demo Street, Sample City", ident, prov, pol, history, symptoms, status, note)).lastrowid)
        db.execute("INSERT INTO notifications (user_id, message, notification_type) VALUES (?, ?, 'registration')",
                   (uid, "Welcome to MEDIQ! (demo account)"))
        db.execute("INSERT INTO notifications (user_id, message, notification_type) VALUES (?, ?, 'verification')",
                   (uid, f"Your verification status is: {status}. {note}"))

    # Availability: every weekday (plus today) from 3 days ago to 14 days ahead
    today = date.today()
    for doctor_id in doctor_ids:
        for offset in range(-3, 15):
            day = today + timedelta(days=offset)
            if day.weekday() >= 5 and offset != 0:
                continue
            for start, end in (("09:00", "12:00"), ("14:00", "17:00")):
                db.execute("INSERT INTO doctor_availability (doctor_id, available_date, start_time, end_time) VALUES (?, ?, ?, ?)",
                           (doctor_id, day.isoformat(), start, end))

    # A few sample appointments (times 09:00 / 10:00 / 11:00 fit every consultation length)
    def appt(patient_idx, doctor_idx, offset, start, end, status):
        return db.execute(
            "INSERT INTO appointments (patient_id, doctor_id, appointment_date, start_time, end_time, status) VALUES (?, ?, ?, ?, ?, ?)",
            (patient_ids[patient_idx], doctor_ids[doctor_idx], (today + timedelta(days=offset)).isoformat(), start, end, status)).lastrowid

    done1 = appt(0, 0, -2, "09:00", "09:30", "Completed")
    done2 = appt(0, 4, -1, "10:00", "10:15", "Completed")
    appt(0, 2, 3, "10:00", "10:20", "Booked")
    appt(4, 1, 2, "09:00", "09:30", "Confirmed")
    appt(4, 3, 4, "11:00", "11:30", "Booked")
    appt(0, 0, 5, "11:00", "11:30", "Cancelled")
    appt(4, 0, 0, "09:00", "09:30", "Booked")     # today, so the dashboards show data

    db.execute("INSERT INTO medical_records (patient_id, doctor_id, appointment_id, symptoms, consultation_notes, diagnosis, visible_to_patient) "
               "VALUES (?, ?, ?, ?, ?, ?, 1)", (patient_ids[0], doctor_ids[0], done1, "Chest tightness",
                                                "ECG normal (demo data). Advised light exercise.", "Mild anxiety-related symptoms"))
    db.execute("INSERT INTO medical_records (patient_id, doctor_id, appointment_id, symptoms, consultation_notes, diagnosis, visible_to_patient) "
               "VALUES (?, ?, ?, ?, ?, ?, 0)", (patient_ids[0], doctor_ids[4], done2, "Fatigue",
                                                "PRIVATE doctor note: not shared with the patient (demo data).", "Vitamin deficiency suspected"))
    db.execute("INSERT INTO audit_logs (user_id, action, entity_type, entity_id) VALUES (NULL, 'database_seeded', 'system', NULL)")
    db.execute("COMMIT")
    db.close()
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Create the MEDIQ database with demo data.")
    parser.add_argument("--reset", action="store_true", help="delete the existing database first")
    args = parser.parse_args()
    if seed(reset=args.reset):
        print(f"Database ready at {Config.DATABASE} with demo data.")
        print(f"All demo accounts use the password: {DEMO_PASSWORD}")
        print("  admin@example.com | dr.verma@example.com | patient1@example.com (Verified)")
    else:
        print("The database already contains users, so nothing was added. Use --reset to start fresh.")
